# Book Management System

## Purpose 

This application reads a list of books from a file as part of a library management system. It allows users to check out books, search by title, display books of a specific type, and display a random list of books. It then will save the new list of books back to the file when the user is done.

## How to Run

To run the program, just run the ApplicationDriver main method. To end select 5 from the menu options to terminate the program.

## Authors

Allyssa Preece, Anusone Soula, Aiden Kopec

### Date: Feb 6, 2022
