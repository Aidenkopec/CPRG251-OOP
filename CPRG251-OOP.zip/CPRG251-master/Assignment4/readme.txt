Project: Movie Management System JDBC

This program allows a user to interact with a movie database to add and delete movies as well as display all movies produced in a year nad a random list of movies. 
It manages the connection and interactions with the database through the use of JDBC.

Date: April 20, 2022
Authors: Allyssa Preece, Anusone Soula, Aiden Kopec

How to Run: open appDriver.java and run the main method.